This is SAMPLETALK language Interpreter Ver.3.2 for Windows.

Copyright (1990-2022) by Andrew Gleibman, Haifa. For a description of 
the language and technology please visit our homepage:

http://sampletalk.github.io. 

This version is for research purposes only. It is a free software 
without any guarantee. Please send your comments/questions to the author: 

Andrew H.Gleibman, PhD. Email: 
gleibman(AT)nialgo.com,
sampletalk(AT)gmail.com.

In this software, SWI-Prolog for Windows is used. It was kindly provided by 
Professor Jan Wielemaker from University of Amsterdam. Please visit 
http://www.swi-prolog.org/ for information about SWI-Prolog.


IMPORTANT:

In this version of Sampletalk interpreter the 1st clause of any Sampletalk 
program is treated as the main program goal. All other clauses are treated
as reasoning rules for resolving this goal.

For running our initial program example AAAI2005.sam, which is described 
in more detail in Section 4 of paper 

www.aaai.org/Papers/Workshops/2005/WS-05-05/WS05-05-010.pdf, 

simply run the batch file

COMPILE_AND_RUN_SAMPLETALK_PROGRAM.BAT.

The results of the reasoning will be printed in file OUTPUT.SAM.

For running another Sampletalk program <PName>.sam (e.g., one of those 
contained in directory EXAMPLES), please modify the batch file by replacing 
parameter AAAI2005.sam with <PName>.sam, taking into account a relative path. 

For controlling the direction and verbosity modes of the program output,
please modify the text file 

SERVICE/sampletalk_interface_options.pl.

Good Luck!