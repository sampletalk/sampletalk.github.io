% 	Modes for running Sampletalk interpreter 
%	(please comment/uncomment-out any of them to change a mode):

	m(write_intermediate_results).	% printing intermediate Sampletalk inference results (verbosity control)
	m(output_to_file_output_sam).	% the inference output will be written into file "output.sam"
%	m(backtracking_sensitivity).	% all possibilities of pairvise matching samples are considered
	m(stop_between_lines).		% the screen-directed printing will stop until the user presses any key
	m(all_decisions).		% all possible solutions of the main Sampletalk goal will be found
	m(debug_mode).			% preventing infinite loops and/or recursions by a hard stop