% SAMPLETALK 3.1 generated Prolog version of Sampletalk program ..\AAAI2005.sam

g('can',0,[
[can,' ' ,undrl([john]),' ' ,see,' ' ,undrl([notebook]),sgnQuestion]
]). 
s('can',1,[
[can,' ' ,undrl([A]),' ' ,see,' ' ,undrl([X]),sgnQuestion],
[undrl([A]),' ' ,can,' ' ,see,' ' ,undrl([X])]
]). 
s('what',2,[
[what,' ' ,can,' ' ,undrl([A]),' ' ,see,sgnQuestion,' ' ,undrl([X])],
[undrl([A]),' ' ,can,' ' ,see,' ' ,undrl([X])]
]). 
s('what',3,[
[what,' ' ,is,' ' ,in,' ' ,undrl([A]),sgnQuestion,' ' ,undrl([X])],
[undrl([X]),' ' ,is,' ' ,in,' ' ,undrl([A])]
]). 
s('what',4,[
[what,' ' ,is,' ' ,visible,' ' ,on,' ' ,undrl([A]),sgnQuestion,' ' ,undrl([X])],
[undrl([X]),' ' ,is,' ' ,visible,' ' ,on,' ' ,undrl([A])]
]). 
s('what',5,[
[what,' ' ,is,' ' ,invisible,' ' ,on,' ' ,undrl([A]),sgnQuestion,' ' ,undrl([X])],
[undrl([X]),' ' ,is,' ' ,in,' ' ,undrl([B])],
[undrl([B]),' ' ,is,' ' ,on,' ' ,undrl([A])],
[sgnTilda,sgnTilda,undrl([X]),' ' ,is,' ' ,visible,' ' ,on,' ' ,undrl([A])]
]). 
s('what',6,[
[what,' ' ,is,' ' ,on,' ' ,undrl([A]),sgnQuestion,' ' ,undrl([X])],
[undrl([X]),' ' ,is,' ' ,on,' ' ,undrl([A])]
]). 
s('what',7,[
[what,' ' ,is,' ' ,on,' ' ,undrl([A]),sgnQuestion,' ' ,undrl([X])],
[undrl([X]),' ' ,is,' ' ,in,' ' ,undrl([B])],
[undrl([B]),' ' ,is,' ' ,on,' ' ,undrl([A])]
]). 
s(undrl(_),8,[
[undrl([A]),' ' ,can,' ' ,see,' ' ,undrl([X])],
[undrl([A]),' ' ,is,' ' ,standing,' ' ,near,' ' ,undrl([B])],
[undrl([X]),' ' ,is,' ' ,visible,' ' ,on,' ' ,undrl([B])]
]). 
s(undrl(_),9,[
[undrl([A]),' ' ,is,' ' ,visible,' ' ,on,' ' ,undrl([B])],
[undrl([A]),' ' ,is,' ' ,on,' ' ,undrl([B])]
]). 
s(undrl(_),10,[
[undrl([A]),' ' ,is,' ' ,visible,' ' ,on,' ' ,undrl([B])],
[undrl([A]),' ' ,is,' ' ,in,' ' ,undrl([open,' ' ,X])],
[undrl([open,' ' ,X]),' ' ,is,' ' ,visible,' ' ,on,' ' ,undrl([B])]
]). 
s(undrl(_),11,[
[undrl([A]),' ' ,is,' ' ,standing,' ' ,near,' ' ,undrl([B])],
[undrl([A]),' ' ,has,' ' ,approached,' ' ,undrl([B])]
]). 
s(undrl(_),12,[
[undrl([book]),' ' ,is,' ' ,in,' ' ,undrl([open,' ' ,box])]
]). 
s(undrl(_),13,[
[undrl([notebook]),' ' ,is,' ' ,in,' ' ,undrl([closed,' ' ,box])]
]). 
s(undrl(_),14,[
[undrl([open,' ' ,box]),' ' ,is,' ' ,on,' ' ,undrl([red,' ' ,table])]
]). 
s(undrl(_),15,[
[undrl([closed,' ' ,box]),' ' ,is,' ' ,on,' ' ,undrl([red,' ' ,table])]
]). 
s(undrl(_),16,[
[undrl([john]),' ' ,has,' ' ,approached,' ' ,undrl([red,' ' ,table])]
]). 