For running the current compiler of SAMPLETALK language (formerly known as SAMPLE language) on a Windows machine, simply unzip all these files into a directory and run program SAMPLETALK.EXE, which is the language interpreter, from this directory.

The User Interface allows you to chose and run any <name>.SAM file, 
which represents some algorithm example.

For more details, refer to 

	1. A. Gleibman. Intelligent Processing of an Unrestricted Text in First Order String Calculus. In: M.L. Gavrilova et al. (Eds.): Trans. on Comput. Sci. V, LNCS 5540, pp. 99–127, 2009. © Springer-Verlag Berlin Heidelberg 2009.  
http://www.springerlink.com/content/lpx735725134502m/ 
	2. A. Gleibman. Knowledge Representation via Verbal Description Generalization: Alternative Programming in Sampletalk Language. In: Workshop on Inference for Textual Question Answering. July 09, 2005 – Pittsburgh, Pennsylvania, pp. 59-68. AAAI-05 -- the Twentieth National Conference on Artificial Intelligence.
http://www.aaai.org/Papers/Workshops/2005/WS-05-05/WS05-05-010.pdf  
	4. A. Gleibman. Synthesis of Text Processing Programs by Example: The SAMPLE Language. In: The issue of the Institute of Theoretical Astronomy of the Russian Academy of Sciences. No.15, 27 pp., 1991. In Russian. English translation is available in Sampletalk homepage sampletalk.github.io.
